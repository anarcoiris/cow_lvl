
# Data sources: websocket->kafka producer, kafka->sqlite consumer, ccxt fetcher, influx writer
